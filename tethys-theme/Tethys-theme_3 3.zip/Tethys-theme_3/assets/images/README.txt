Add your volcano background image here as `volcano-bg.jpg` (ideally 2400px+ wide). The homepage references `./public/images/volcano-bg.jpg`.

For the Signals from Tethys landing page, drop a cinematic 16:9 still as `field-hero.jpg` (minimum 2400px wide). The hero section references `./public/images/field-hero.jpg`.

New background slots:
- `about-bg.jpg` for the About hero (`./images/about-bg.jpg`)
- `support-bg.jpg` for the Support / Join the Circle hero
- `characters-bg.jpg` for the Characters feature spread

Use temporary placeholders if needed, but swap in final art (2400px+ recommended) to keep the gradients crisp.
